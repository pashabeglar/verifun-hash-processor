# -*- coding: utf-8 -*-
"""
"""
#openFrom = "_testInstr.txt"
#openFrom = "_testInstr2.txt"
#openFrom = "_testInstr3.txt"
openFrom = "_testInstr4.txt"
writeTo  = "_testInstr_b.mem"
#openFrom = "_instrMEM.txt"
#writeTo  = "_instrMEM_b.mem"

sep = '_'

def regAddr(width, regno):
    tempString = '{0:0>' + str(width) + '}'
    return tempString.format(bin(int(regno))[2:])

regBinDict = {
           'z'     : regAddr(5,0),
           'v0'    : regAddr(5,1),
           'v1'    : regAddr(5,2),
           'v2'    : regAddr(5,3),
           'v3'    : regAddr(5,4),
           'v4'    : regAddr(5,5),
           'v5'    : regAddr(5,6),
           'v6'    : regAddr(5,7),
           'v7'    : regAddr(5,8),
           'v8'    : regAddr(5,9),
           'v9'    : regAddr(5,10),
           'n'     : regAddr(5,11),
           'nlim'  : regAddr(5,12),
           'kb'    : regAddr(5,13),
           'wb'    : regAddr(5,14),
           'mb'    : regAddr(5,15),
           'h0'    : regAddr(5,16),
           'h1'    : regAddr(5,17),
           'h2'    : regAddr(5,18),
           'h3'    : regAddr(5,19),
           'h4'    : regAddr(5,20),
           'h5'    : regAddr(5,21),
           'h6'    : regAddr(5,22),
           'h7'    : regAddr(5,23),
           'a0'    : regAddr(5,24),
           'a1'    : regAddr(5,25),
           'a2'    : regAddr(5,26),
           'a3'    : regAddr(5,27),
           'a4'    : regAddr(5,28),
           'a5'    : regAddr(5,29),
           'a6'    : regAddr(5,30),
           'a7'    : regAddr(5,31)
          }

opCodeBinDict = {
        'nops'    : '000000',
        'add'     : '000000',
        'and'     : '000000',
        'or'      : '000000',
        'sll'     : '000000',
        'addi'    : '001000',
        'ori'     : '001101',
        'lui'     : '001111',
        'lw'      : '100011',
        'sw'      : '101011',
        'beq'     : '000100',
        'bne'     : '000101',
        'j'       : '000010',
        'hf_ch'   : '111000',
        'hf_maj'  : '111000',
        'hf_s0'   : '111000',
        'hf_s1'   : '111000',
        'hf_o0'   : '111000',
        'hf_o1'   : '111000',
        'hf_swcr' : '111001',
        'hf_done' : '111010',
        }



with open(openFrom,'r') as fileRd:
    with open(writeTo, 'w')as fileWr:
        
        read_data = fileRd.read()
        instrList  = read_data.split('\n')
        
        print('Contents of "{0}":'.format(openFrom))
        for line in instrList:
            print(line)
        
        instrCounter = 0
        lineCounter = 0
        instrBinList = []
        
        print('\n\nConverting to Machine Code:')
        for line in instrList:
            objList = line.split()
            
            commentFlag = False
            commenti = 0
            #find comment line
            for obj in objList:
                if obj[0] == '#':
                    commentFlag = True
                    break
                commenti += 1
                
            lineNoComment = ' '.join(objList[0:commenti])
            
            #print(len(line), end='    ')
            if (len(objList)>0):
                instr = objList[0]
                
                if instr[0] == '#':
                    lineCounter += 1
                    continue
                
                if instr == 'nops':
                    instrBin = '0'*32
                
                elif instr == 'add':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = regBinDict[objList[3]]
                    Rd = regBinDict[objList[1]]
                    shamt = "00000"
                    func  = "100000"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,shamt,func])
                
                elif instr == 'and':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = regBinDict[objList[3]]
                    Rd = regBinDict[objList[1]]
                    shamt = "00000"
                    func  = "100100"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,shamt,func])
                    
                elif instr == 'or':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = regBinDict[objList[3]]
                    Rd = regBinDict[objList[1]]
                    shamt = "00000"
                    func  = "100101"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,shamt,func])
                
                elif instr == 'sll':
                    opcode = opCodeBinDict[instr]
                    Rs = '0'*5
                    Rt = regBinDict[objList[2]]
                    Rd = regBinDict[objList[1]]
                    shamt = "{0:0>5}".format(bin(int(objList[3], 0))[2:])
                    func  = "000000"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,shamt,func])
                    
                elif instr == 'addi':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = regBinDict[objList[1]]
                    imm = "{0:0>16}".format(bin(int(objList[3], 0))[2:])
                    instrBin = sep.join([opcode,Rs,Rt,imm])
                    
                elif instr == 'ori':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = regBinDict[objList[1]]
                    immstr = objList[3]
                    imm = "{0:0>16}".format(bin(int(objList[3],0))[2:])
                    instrBin = sep.join([opcode,Rs,Rt,imm])
                    
                elif instr == 'lui':
                    opcode = opCodeBinDict[instr]
                    Rs = '0'*5
                    Rt = regBinDict[objList[1]]
                    imm = "{0:0>16}".format(bin(int(objList[2],0))[2:])
                    instrBin = sep.join([opcode,Rs,Rt,imm])
                
                elif instr == 'lw':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[3]]
                    Rt = regBinDict[objList[1]]
                    imm = "{0:0>16}".format(bin(int(objList[2],0))[2:])
                    instrBin = sep.join([opcode,Rs,Rt,imm])
                    
                elif instr == 'sw':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[3]]
                    Rt = regBinDict[objList[1]]
                    imm = "{0:0>16}".format(bin(int(objList[2],0))[2:])
                    instrBin = sep.join([opcode,Rs,Rt,imm])
                    
                elif instr == 'beq':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = regBinDict[objList[1]]
                    imm = "{0:0>16}".format(bin(int(objList[3],0))[2:])
                    instrBin = sep.join([opcode,Rs,Rt,imm])
                    
                elif instr == 'bne':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = regBinDict[objList[1]]
                    imm = "{0:0>16}".format(bin(int(objList[3],0))[2:])
                    instrBin = sep.join([opcode,Rs,Rt,imm])
                
                elif instr == 'j':
                    opcode = opCodeBinDict[instr]
                    addr = "{0:0>26}".format(bin(int(objList[1],0))[2:])
                    instrBin = sep.join([opcode,addr])
                
                elif instr == 'hf_ch':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = regBinDict[objList[3]]
                    Rd = regBinDict[objList[1]]
                    Ru = regBinDict[objList[4]]
                    func  = "000000"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,Ru,func])
                
                elif instr == 'hf_maj':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = regBinDict[objList[3]]
                    Rd = regBinDict[objList[1]]
                    Ru = regBinDict[objList[4]]
                    func  = "000001"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,Ru,func])
                
                elif instr == 'hf_s0':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = '0'*5
                    Rd = regBinDict[objList[1]]
                    Ru = '0'*5
                    func  = "000010"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,Ru,func])
                    
                elif instr == 'hf_s1':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = '0'*5
                    Rd = regBinDict[objList[1]]
                    Ru = '0'*5
                    func  = "000011"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,Ru,func])
                
                elif instr == 'hf_o0':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = '0'*5
                    Rd = regBinDict[objList[1]]
                    Ru = '0'*5
                    func  = "000100"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,Ru,func])
                
                elif instr == 'hf_o1':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[2]]
                    Rt = '0'*5
                    Rd = regBinDict[objList[1]]
                    Ru = '0'*5
                    func  = "000101"
                    instrBin = sep.join([opcode,Rs,Rt,Rd,Ru,func])
                
                elif instr == 'hf_swcr':
                    opcode = opCodeBinDict[instr]
                    Rs = regBinDict[objList[1]]
                    Rt = '0'*5
                    Rd = '0'*5
                    Ru = '0'*5
                    func  = regAddr(6,int(objList[2],0))
                    instrBin = sep.join([opcode,Rs,Rt,Rd,Ru,func])
                    
                elif instr == 'hf_done':
                    opcode = opCodeBinDict[instr]
                    Rs = '0'*5
                    Rt = '0'*5
                    Rd = '0'*5
                    Ru = '0'*5
                    func  = '0'*6
                    instrBin = sep.join([opcode,Rs,Rt,Rd,Ru,func])
                
                else:
                    instrBin = lineNoComment
                
                
                instrBinList.append(instrBin)
                    
#                print("{0:37} [{1}] {2}".format(instrBin, instrCounter,line))
                print("[{0}] {1}".format(instrCounter,line))
                instrCounter += 1
            lineCounter += 1
            
        
        print('\n\nContents of "{0}":'.format(writeTo))
        i=0
        for line in instrBinList:
            fileWr.write("{0:37} //[{1}]\n".format(line, i))
            print("{0:37} //[{1}]".format(line, i))
            i += 1
            
print("\n\ndone :D")